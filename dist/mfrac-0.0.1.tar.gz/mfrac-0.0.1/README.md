# fraction
Makes &lt;class 'frac'> in Python3

ex:

n = frac(1, 2)

m = frac(m=3, n=2)

print(n*m)


This code prints '1/3'.

n is 1/2, and m is 2/3.


You can add, subtract, multiplicate, divide Fractions.

how to install: python3 -m pip install --index-url https://test.pypi.org/simple/ fraction