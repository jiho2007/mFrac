#__init__.py
#Script By jiho2007

import .frac
__all__ = ['frac', 'error']
