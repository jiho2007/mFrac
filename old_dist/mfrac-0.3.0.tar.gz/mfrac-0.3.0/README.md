# mFrac
**A Simple Fraction Python Library**

**Feature:**  
This Library implements 'frac' class.  
You can add, subtract, multiplicate, divide Fractions.

The Lastest Version Of mFrac is 0.2.1

**How to install:** *pip install -i https://test.pypi.org/simple/ mfrac*  
**How to upgrade:** *pip install -i https://test.pypi.org/simple/ mfrac --upgrade*


**Wiki:** [View On Github Pages](https://jiho2007.github.io/mFrac/)

